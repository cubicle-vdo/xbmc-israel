# -*- coding: iso-8859-1 -*-
""" CryptoPy - a pure python cryptographic libraries

    crypto.passwords package

    Copyright � (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""   
